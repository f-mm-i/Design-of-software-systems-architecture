import datetime
from typing import List, Dict, Any, Tuple, Set

import matplotlib.pyplot as plt
import networkx as nx
import vk_api
import pandas as pd


def compute_age(bdate: str):
    """
    Преобразуем дату рождения 'DD.MM.YYYY' в возраст (годы).
    Если года нет (формат 'DD.MM'), возвращаем None.
    """
    parts = bdate.split('.')
    if len(parts) != 3:
        return None
    try:
        year = int(parts[2])
    except ValueError:
        return None
    current_year = datetime.datetime.now().year
    return current_year - year


def get_group_members(vk, group_id: str, max_members: int = 5000) -> List[Dict[str, Any]]:
    """
    Получаем участников группы с нужными полями.
    group_id – короткое имя или числовой ID БЕЗ минуса (например 'apiclub' или '123456').
    max_members – максимум подписчиков, которых забираем (для ограничения объёма).
    """
    members: List[Dict[str, Any]] = []
    offset = 0
    batch = 1000

    while offset < max_members:
        count = min(batch, max_members - offset)

        resp = vk.groups.getMembers(
            group_id=group_id,
            offset=offset,
            count=count,
            fields="sex,bdate,city"
        )

        items = resp.get('items', [])
        members.extend(items)

        offset += count
        if len(items) < count:

            break

    return members


def analyze_members(members: List[Dict[str, Any]]) -> Tuple[pd.DataFrame, Dict[str, Any]]:
    """
    Делаем DataFrame по участникам и считаем базовую статистику:
    - распределение по полу
    - средний/медианный возраст (по тем, у кого есть год рождения)
    - топ-10 городов
    """
    df = pd.DataFrame(members)


    sex_map = {0: 'unknown', 1: 'female', 2: 'male'}
    if 'sex' in df.columns:
        df['sex_label'] = df['sex'].map(sex_map)
    else:
        df['sex_label'] = 'unknown'


    if 'bdate' in df.columns:
        df['age'] = df['bdate'].apply(
            lambda d: compute_age(d) if isinstance(d, str) else None
        )
    else:
        df['age'] = None


    if 'city' in df.columns:
        df['city_title'] = df['city'].apply(
            lambda c: c.get('title') if isinstance(c, dict) else None
        )
    else:
        df['city_title'] = None

    stats = {
        'total': len(df),
        'by_sex': df['sex_label'].value_counts(dropna=False).to_dict(),
        'age_mean': float(df['age'].dropna().mean()) if df['age'].dropna().size else None,
        'age_median': float(df['age'].dropna().median()) if df['age'].dropna().size else None,
        'by_city_top10': df['city_title'].value_counts().head(10).to_dict()
    }

    return df, stats


def plot_demographics(df1: pd.DataFrame, df2: pd.DataFrame,
                      group1_name: str, group2_name: str) -> None:
    """
    Рисуем:
    - столбчатые диаграммы по полу
    - гистограммы по возрасту
    для двух групп рядом.
    """


    fig, axes = plt.subplots(1, 2, figsize=(10, 4))
    for ax, df, title in zip(axes, [df1, df2], [group1_name, group2_name]):
        df['sex_label'].value_counts().plot(kind='bar', ax=ax)
        ax.set_title(f'Пол подписчиков: {title}')
        ax.set_xlabel('Пол')
        ax.set_ylabel('Количество')
    plt.tight_layout()
    plt.show()

 
    fig, axes = plt.subplots(1, 2, figsize=(10, 4))
    for ax, df, title in zip(axes, [df1, df2], [group1_name, group2_name]):
        ages = df['age'].dropna()
        if not ages.empty:
            ax.hist(ages, bins=range(10, 80, 2))
        ax.set_title(f'Возраст подписчиков: {title}')
        ax.set_xlabel('Возраст')
        ax.set_ylabel('Количество')
    plt.tight_layout()
    plt.show()


def build_and_draw_graph(members1_ids: Set[int],
                         members2_ids: Set[int],
                         group1_name: str,
                         group2_name: str,
                         max_users_for_graph: int = 300) -> None:
    """
    Строим простой социальный граф:
    - две вершины: "group1", "group2"
    - вершины-пользователи
    - ребро user–group, если пользователь состоит в группе
    (получается двудольный граф "группы – пользователи").
    """

    G = nx.Graph()


    G.add_node('group1', label=group1_name, kind='group')
    G.add_node('group2', label=group2_name, kind='group')


    inter = list(members1_ids & members2_ids)
    only1 = list(members1_ids - members2_ids)
    only2 = list(members2_ids - members1_ids)

    def sample(lst):
        return lst[:max_users_for_graph]

    inter = sample(inter)
    only1 = sample(only1)
    only2 = sample(only2)

    # Вершины-пользователи и рёбра
    for uid in only1:
        G.add_node(uid, kind='user', group='only1')
        G.add_edge(uid, 'group1')

    for uid in only2:
        G.add_node(uid, kind='user', group='only2')
        G.add_edge(uid, 'group2')

    for uid in inter:
        G.add_node(uid, kind='user', group='both')
        G.add_edge(uid, 'group1')
        G.add_edge(uid, 'group2')

    pos = nx.spring_layout(G, k=0.2, iterations=50)

    colors = []
    sizes = []
    for n, attrs in G.nodes(data=True):
        if attrs.get('kind') == 'group':
            colors.append('red')
            sizes.append(400)
        else:
            grp = attrs.get('group')
            if grp == 'both':
                colors.append('orange')
            elif grp == 'only1':
                colors.append('blue')
            else:
                colors.append('green')
            sizes.append(50)

    nx.draw(
        G,
        pos,
        node_color=colors,
        node_size=sizes,
        with_labels=False,
        edge_color='gray'
    )


    group_labels = {'group1': group1_name, 'group2': group2_name}
    nx.draw_networkx_labels(G, pos, labels=group_labels, font_size=10, font_color='black')

    plt.title('Граф пользователей двух групп (двудольный граф)')
    plt.axis('off')
    plt.show()



def main():

    access_token = "vk1.a.5PR6lHR9g0TlGG3cGGdTRD0JIVvlZjP52UdEMxlF8N9d3pgaRoK4iNK-nCHYf8qTHwrZxcpj5kRedjiSyY1YSybFlgO6GFd_bXlR4oux1WFgOxk-mfx_APiCu_CW7r_N1WSKgi49_2sDC71uzCFXo_J9G8Vgyo3XzHeGMpZ0yZUZPtiCgWgkek7S1SHXOzSKRXw6Mm6jGXTFGyU5o9ZhPA"

    group1 = 71991592
    group2 = 9400288


    #  ограничим максимум выгрузки из группы
    max_members = 20000

    vk_session = vk_api.VkApi(token=access_token)
    vk = vk_session.get_api()


    group1_info = vk.groups.getById(group_id=group1)[0]
    group2_info = vk.groups.getById(group_id=group2)[0]
    group1_name = group1_info['name']
    group2_name = group2_info['name']

    print("Группа 1:", group1_name)
    print("Группа 2:", group2_name)

    print("\nЗагружаем участников первой группы...")
    members1 = get_group_members(vk, group1, max_members=max_members)
    print(f"Получено участников группы 1: {len(members1)}")

    print("\nЗагружаем участников второй группы...")
    members2 = get_group_members(vk, group2, max_members=max_members)
    print(f"Получено участников группы 2: {len(members2)}")

 
    df1, stats1 = analyze_members(members1)
    df2, stats2 = analyze_members(members2)

    print("\nСтатистика по группе 1:")
    print(stats1)

    print("\nСтатистика по группе 2:")
    print(stats2)

    ids1 = set(df1['id'].dropna().astype(int).tolist())
    ids2 = set(df2['id'].dropna().astype(int).tolist())
    inter = ids1 & ids2
    print(f"\nПересечение подписчиков: {len(inter)} пользователей")

    plot_demographics(df1, df2, group1_name, group2_name)

   
    build_and_draw_graph(ids1, ids2, group1_name, group2_name,
                         max_users_for_graph=300)


if __name__ == "__main__":
    main()
