# -*- coding: utf-8 -*-
"""
Сбор отзывов с Кинопоиска (через Selenium) и анализ тональности.

Используем:
- общий рейтинг фильма: span[data-tid="939058a8"] (8.7 и т.п.)
- тип рецензии в блоке <ul class="voter">:
    положительная / отрицательная / нейтральная рецензия
  -> review_label = +1 / -1 / 0

Сравниваем:
1) review_label vs sent_score (тональность текста отзыва)
2) film_rating vs средняя sent_score по фильму
"""

import re
import time
import random

from bs4 import BeautifulSoup
import pandas as pd
import matplotlib.pyplot as plt

from selenium import webdriver
from selenium.webdriver.chrome.options import Options

# ------------------------
# 0. Список фильмов
# ------------------------

MOVIES = {
    "Интерстеллар": "258687",
    "Начало": "447301",
    "Матрица": "301",
    "Форрест Гамп": "448",
    "Побег из Шоушенка": "326",
    "Бойцовский клуб": "361",
    "Крёстный отец": "325",
    "Аватар": "251733",
    "Темный рыцарь": "111543",
    "Зеленая миля": "435",
}

REVIEWS_PER_MOVIE = 15  # >=10 нужно по условию, возьмем чуть больше


# ------------------------
# 1. Selenium
# ------------------------

def create_driver():
    options = Options()
    # если не нужен видимый браузер, можно раскомментить:
    # options.add_argument("--headless=new")

    options.add_argument(
        "user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
        "AppleWebKit/537.36 (KHTML, like Gecko) "
        "Chrome/120.0 Safari/537.36"
    )

    driver = webdriver.Chrome(options=options)
    driver.set_window_size(1300, 900)
    return driver


# ------------------------
# 2. Очень простой анализ тональности для RU
# ------------------------

POS_WORDS = {
    "отличный", "классный", "супер", "прекрасный", "потрясающий", "шедевр",
    "замечательный", "интересный", "гениальный", "великолепный", "понравился",
    "понравилась", "понравилось", "любимый", "сильный", "крутой", "удивительный",
}

NEG_WORDS = {
    "плохой", "ужасный", "скучный", "отстой", "тупой", "отвратительный",
    "слабый", "разочарование", "разочаровал", "разочаровала", "разочаровало",
    "ненавижу", "мерзкий", "бред", "глупый", "скучно",
}


def simple_ru_sentiment_score(text: str) -> float:
    """
    score = (pos - neg) / (pos + neg)
    ~ диапазон [-1, 1], 0 — нейтрально / нет слов из словарей.
    """
    tokens = re.findall(r"[А-ЯЁа-яё]+", text.lower(), flags=re.UNICODE)
    pos = sum(1 for t in tokens if t in POS_WORDS)
    neg = sum(1 for t in tokens if t in NEG_WORDS)
    if pos + neg == 0:
        return 0.0
    return (pos - neg) / (pos + neg)


# ------------------------
# 3. Рейтинг фильма (страница фильма)
# ------------------------

def get_kp_film_rating(kp_id: str, driver) -> float | None:
    url = f"https://www.kinopoisk.ru/film/{kp_id}/"
    try:
        driver.get(url)
        time.sleep(3)
    except Exception as e:
        print(f"  [!] Не удалось открыть страницу фильма: {e}")
        return None

    soup = BeautifulSoup(driver.page_source, "html.parser")

    rating_span = soup.select_one('span[data-tid="939058a8"]')
    if rating_span is None:
        rating_span = soup.select_one('span[class*="styles_ratingKpTop"]')

    if not rating_span:
        print("  [!] Не нашёл рейтинг на странице (span[data-tid='939058a8']).")
        return None

    text = rating_span.get_text(strip=True).replace(",", ".")
    try:
        return float(text)
    except ValueError:
        print(f"  [!] Не удалось преобразовать рейтинг '{text}' в число.")
        return None


# ------------------------
# 4. Отзывы (div.response + span[itemprop="reviewBody"] + ul.voter)
# ------------------------

def parse_review_label(block) -> int | None:
    """
    Достаём из блока отзыва тип рецензии:
    +1 — положительная, -1 — отрицательная, 0 — нейтральная.
    Основано на ul.voter и title вида "положительная рецензия" и т.п.
    """
    voter = block.select_one("ul.voter")
    if not voter:
        return None

    html = str(voter).lower()

    if "положительная рецензия" in html:
        return 1
    if "отрицательная рецензия" in html:
        return -1
    if "нейтральная рецензия" in html:
        return 0

    return None


def get_kp_reviews_selenium(kp_id: str, max_reviews: int, driver) -> list[dict]:
    """
    Заходит на https://www.kinopoisk.ru/film/<kp_id>/reviews/
    и собирает отзывы:
        text  — текст отзыва
        label — {+1, 0, -1} по типу рецензии (полож / нейтр / отриц)
    """
    url = f"https://www.kinopoisk.ru/film/{kp_id}/reviews/"
    try:
        driver.get(url)
        time.sleep(4)
    except Exception as e:
        print(f"  [!] Не удалось открыть страницу отзывов: {e}")
        return []

    print("  Страница отзывов:", driver.title)

    soup = BeautifulSoup(driver.page_source, "html.parser")
    review_blocks = soup.select("div.response")
    print("  Найдено блоков div.response:", len(review_blocks))

    reviews: list[dict] = []

    for block in review_blocks:
        text_span = block.select_one('span[itemprop="reviewBody"]')
        if not text_span:
            continue

        text = text_span.get_text(strip=True)
        if not text or len(text) < 30:
            continue

        label = parse_review_label(block)

        reviews.append({
            "text": text,
            "label": label,  # может быть None, если вдруг не нашли voter
        })

        if len(reviews) >= max_reviews:
            break

    print("  Итоговое число отзывов:", len(reviews))
    return reviews


# ------------------------
# 5. Основной скрипт
# ------------------------

def main():
    driver = create_driver()
    all_rows = []

    try:
        for movie_title, kp_id in MOVIES.items():
            print(f"\n=== Фильм '{movie_title}' (kp_id={kp_id}) ===")

            try:
                film_rating = get_kp_film_rating(kp_id, driver)
                print("  Рейтинг фильма:", film_rating)

                reviews = get_kp_reviews_selenium(kp_id, REVIEWS_PER_MOVIE, driver)
            except Exception as e:
                print(f"  [!] Ошибка при обработке фильма, пропускаю его: {e}")
                continue

            if not reviews:
                print("  [!] Отзывов не найдено, фильм пропускаем.")
                continue

            for i, r in enumerate(reviews):
                text = r["text"]
                label = r["label"]  # +1 / 0 / -1 / None
                sent = simple_ru_sentiment_score(text)

                all_rows.append({
                    "movie": movie_title,
                    "kp_id": kp_id,
                    "film_rating": film_rating,
                    "review_index": i,
                    "review_label": label,
                    "review_text": text,
                    "sent_score": sent,
                })

            time.sleep(random.uniform(1.0, 2.0))

    finally:
        driver.quit()

    if not all_rows:
        print("\n[!] Не удалось собрать ни одного отзыва. Проверяй селекторы.")
        return

    df = pd.DataFrame(all_rows)
    print("\nПервые строки DataFrame:")
    print(df.head())

    df.to_csv("kp_reviews_sentiment.csv", index=False, encoding="utf-8")
    print("\nДанные сохранены в kp_reviews_sentiment.csv")

    # ----- анализ: только отзывы, где удалось определить label -----
    df_labeled = df.dropna(subset=["review_label"]).copy()
    print(f"\nВсего отзывов: {len(df)}, с типом рецензии (label): {len(df_labeled)}")

    if not df_labeled.empty:
        # корреляция между "мнение пользователя" и нашей тональностью
        corr = df_labeled[["review_label", "sent_score"]].corr()
        print("\nКорреляция: review_label (+1/0/-1) vs sent_score:")
        print(corr)

        # средний sent_score по каждому типу рецензии
        mean_sent_by_label = (
            df_labeled.groupby("review_label")["sent_score"]
            .mean()
            .reset_index()
            .sort_values("review_label")
        )
        print("\nСредний sent_score по типу рецензии:")
        print(mean_sent_by_label)
    else:
        print("\n[!] Ни одного отзыва с распознанным типом рецензии (ul.voter) не найдено.")

    # ----- статистика по фильмам -----
    movie_stats = (
        df.groupby("movie")
        .agg(
            film_rating=("film_rating", "first"),
            mean_sentiment=("sent_score", "mean"),
            count_reviews=("review_text", "count"),
        )
        .reset_index()
    )

    print("\nСтатистика по фильмам:")
    print(movie_stats)

    movie_stats.to_csv("kp_movie_stats.csv", index=False, encoding="utf-8")

    # ----- графики -----

    # 1) связь общего рейтинга фильма и средней тональности отзывов
    if not movie_stats.empty:
        plt.figure(figsize=(8, 5))
        plt.scatter(movie_stats["film_rating"], movie_stats["mean_sentiment"])
        for _, row in movie_stats.iterrows():
            plt.text(row["film_rating"] + 0.02,
                     row["mean_sentiment"] + 0.02,
                     row["movie"],
                     fontsize=8)
        plt.xlabel("Рейтинг фильма на Кинопоиске")
        plt.ylabel("Средняя тональность отзывов (sent_score)")
        plt.title("Рейтинг фильма vs средняя тональность отзывов (Кинопоиск)")
        plt.grid(True)
        plt.tight_layout()
        plt.savefig("kp_movies_rating_vs_sentiment.png", dpi=200)
        plt.show()

    # 2) распределение тональностей всех отзывов
    plt.figure(figsize=(8, 5))
    plt.hist(df["sent_score"], bins=20)
    plt.xlabel("Тональность отзыва (sent_score)")
    plt.ylabel("Количество отзывов")
    plt.title("Распределение тональностей отзывов")
    plt.grid(True)
    plt.tight_layout()
    plt.savefig("kp_sentiment_hist.png", dpi=200)
    plt.show()


if __name__ == "__main__":
    main()
