import vk_api
from urllib.request import urlretrieve
import os
import math
import time

ACCESS_TOKEN = "vk1.a.5PR6lHR9g0TlGG3cGGdTRD0JIVvlZjP52UdEMxlF8N9d3pgaRoK4iNK-nCHYf8qTHwrZxcpj5kRedjiSyY1YSybFlgO6GFd_bXlR4oux1WFgOxk-mfx_APiCu_CW7r_N1WSKgi49_2sDC71uzCFXo_J9G8Vgyo3XzHeGMpZ0yZUZPtiCgWgkek7S1SHXOzSKRXw6Mm6jGXTFGyU5o9ZhPA"

OWNER_ID = -665159 


#    Возможные типы: s, m, x, y, z, w и др.

TARGET_SIZE_TYPE = "m"


BASE_SAVE_FOLDER = "saved"

def choose_photo_url_by_size(sizes, target_type):
    """
    Выбрать URL фото нужного размера.
    Если нужный тип не найден — берём самое большое фото.
    """

    for size in sizes:
        if size.get("type") == target_type:
            return size.get("url")

    best = None
    best_square = -1
    for size in sizes:
        w = size.get("width", 0)
        h = size.get("height", 0)
        square = w * h
        if square > best_square:
            best_square = square
            best = size

    return best.get("url") if best else None


def main():
    vk_session = vk_api.VkApi(token=ACCESS_TOKEN)
    vk = vk_session.get_api()
    if not os.path.exists(BASE_SAVE_FOLDER):
        os.mkdir(BASE_SAVE_FOLDER)
    group_folder = os.path.join(BASE_SAVE_FOLDER, f"group{abs(OWNER_ID)}")
    if not os.path.exists(group_folder):
        os.mkdir(group_folder)
    albums = vk.photos.getAlbums(owner_id=OWNER_ID)
    albums_items = albums.get("items", [])

    if not albums_items:
        print("У группы нет фотоальбомов или доступ к ним ограничен.")
        return

    print(f"Найдено альбомов: {len(albums_items)}")

    total_photos_all_albums = 0
    total_downloaded = 0
    total_errors = 0
    start_time = time.time()

    for album in albums_items:
        album_id = album.get("id")
        album_title = album.get("title", f"album{album_id}")
        photos_count = album.get("size", 0)

        print(f"\n=== Альбом ID {album_id} — \"{album_title}\" ===")
        print(f"Всего фото в альбоме: {photos_count}")

        safe_title = "".join(
            c if c.isalnum() or c in " _-" else "_" for c in album_title
        )
        album_folder_name = f"album{album_id}_{safe_title}"
        photo_folder = os.path.join(group_folder, album_folder_name)

        if not os.path.exists(photo_folder):
            os.mkdir(photo_folder)

        counter = 0
        breaken = 0

        if photos_count == 0:
            print("Альбом пуст.")
            continue

        for j in range(math.ceil(photos_count / 1000)):
            photos = vk.photos.get(
                owner_id=OWNER_ID,
                album_id=album_id,
                count=1000,
                offset=j * 1000
            )

            for photo in photos.get("items", []):
                counter += 1
                total_photos_all_albums += 1

                sizes = photo.get("sizes", [])
                url = choose_photo_url_by_size(sizes, TARGET_SIZE_TYPE)

                if not url:
                    print(f"Не удалось подобрать URL для фото #{counter}, пропуск.")
                    breaken += 1
                    total_errors += 1
                    continue

                prog_album = round(100 / photos_count * counter, 2)

                print(
                    f"Альбом {album_id}: "
                    f"загружаю фото № {counter} из {photos_count} "
                    f"({prog_album} %)"
                )
                photo_id = photo.get("id")
                file_name = f"{str(photo_id)[0:10]}.jpg"

                save_path = os.path.join(photo_folder, file_name)

                try:
                    urlretrieve(url, save_path)
                    total_downloaded += 1
                except Exception as e:
                    print(f"Ошибка при загрузке: {e}. Файл пропущен.")
                    breaken += 1
                    total_errors += 1
                    continue

        print(
            f"ИТОГО по альбому {album_id}: "
            f"загружено {counter - breaken} файлов, "
            f"ошибок: {breaken}."
        )

    total_time = round(time.time() - start_time, 1)
    print("\n================ ИТОГИ =================")
    print(f"Всего фото (по альбомам): {total_photos_all_albums}")
    print(f"Успешно загружено: {total_downloaded}")
    print(f"Не удалось загрузить: {total_errors}")
    print(f"Затрачено времени: {total_time} сек.")


if __name__ == "__main__":
    main()
