# -*- coding: utf-8 -*-
"""
Задача 3. Анализ тональности текстов отзывов о фильмах (IMDb)
1) Скрапинг отзывов
2) Анализ тональности (VADER)
3) Сравнение рейтинга пользователя и тональности
"""

import requests
from bs4 import BeautifulSoup
import pandas as pd
import time
import random
import matplotlib.pyplot as plt
import nltk
from nltk.sentiment import SentimentIntensityAnalyzer

# -----------------------------------------------------------------------------
# 0. Подготовка: nltk и список фильмов
# -----------------------------------------------------------------------------

# СКАЧИВАЕМ словарь VADER (нужно один раз)
nltk.download('vader_lexicon')

sia = SentimentIntensityAnalyzer()

# Список фильмов: {название: imdb_id}
# ЗАМЕНИ на свои 10 фильмов!
MOVIES = {
    "Inception": "tt1375666",
    "The Matrix": "tt0133093",
    "The Dark Knight": "tt0468569",
    "Interstellar": "tt0816692",
    "Fight Club": "tt0137523",
    "Forrest Gump": "tt0109830",
    "The Shawshank Redemption": "tt0111161",
    "The Godfather": "tt0068646",
    "Pulp Fiction": "tt0110912",
    "Avatar": "tt0499549",
}

# Сколько отзывов минимум на фильм пытаемся собрать
REVIEWS_PER_MOVIE = 15


# -----------------------------------------------------------------------------
# 1. Функция для получения отзывов одного фильма
# -----------------------------------------------------------------------------

def get_imdb_reviews_for_movie(imdb_id, max_reviews=20):
    """
    Скачивает отзывы с IMDb для одного фильма по его imdb_id (например, 'tt1375666').
    Возвращает список словарей: [{"text": ..., "rating": int или None}, ...]
    """

    reviews = []

    # Базовый URL страницы отзывов
    base_url = f"https://www.imdb.com/title/{imdb_id}/reviews"

    # Параметры (можно сортировать, фильтровать и т.п.)
    params = {
        "sort": "submissionDate",
        "dir": "desc",
        "ratingFilter": "0"
    }

    headers = {
        # Немного маскируемся под браузер
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                      "AppleWebKit/537.36 (KHTML, like Gecko) "
                      "Chrome/120.0 Safari/537.36"
    }

    # Простой вариант — берем только первую страницу.
    # Для учебной задачи 10-20 отзывов с первой страницы обычно хватает.
    resp = requests.get(base_url, params=params, headers=headers)
    if resp.status_code != 200:
        print(f"Ошибка при загрузке страницы для {imdb_id}: {resp.status_code}")
        return reviews

    soup = BeautifulSoup(resp.text, "html.parser")

    # На IMDb отзывы обычно лежат в блоках с классом "review-container"
    review_blocks = soup.find_all("div", class_="review-container")

    for block in review_blocks:
        # Текст отзыва
        text_tag = block.find("div", class_="text")
        if text_tag is None:
            # Иногда класс может быть "text show-more__control"
            text_tag = block.find("div", class_="text show-more__control")

        if text_tag is None:
            continue

        text = text_tag.get_text(strip=True)

        # Рейтинг пользователя (может отсутствовать)
        rating_block = block.find("span", class_="rating-other-user-rating")
        user_rating = None
        if rating_block is not None:
            # формат "8/10" -> берем первое число
            score_span = rating_block.find("span")
            if score_span is not None:
                try:
                    user_rating = int(score_span.get_text(strip=True))
                except ValueError:
                    user_rating = None

        reviews.append({
            "text": text,
            "rating": user_rating
        })

        if len(reviews) >= max_reviews:
            break

    return reviews


# -----------------------------------------------------------------------------
# 2. Анализ тональности текста отзыва
# -----------------------------------------------------------------------------

def get_sentiment(text):
    """
    Возвращает словарь metrik VADER:
    {
        'neg': ...,
        'neu': ...,
        'pos': ...,
        'compound': ...
    }
    Нас в основном будет интересовать 'compound' (-1..1).
    """
    return sia.polarity_scores(text)


# -----------------------------------------------------------------------------
# 3. Сбор данных по всем фильмам
# -----------------------------------------------------------------------------

all_data = []

for movie_title, imdb_id in MOVIES.items():
    print(f"Скачиваем отзывы для фильма '{movie_title}' ({imdb_id})...")
    reviews = get_imdb_reviews_for_movie(imdb_id, max_reviews=REVIEWS_PER_MOVIE)
    print(f"  Получено отзывов: {len(reviews)}")

    for i, review in enumerate(reviews):
        text = review["text"]
        rating = review["rating"]

        s = get_sentiment(text)

        all_data.append({
            "movie": movie_title,
            "imdb_id": imdb_id,
            "review_index": i,
            "user_rating": rating,
            "review_text": text,
            "sent_neg": s["neg"],
            "sent_neu": s["neu"],
            "sent_pos": s["pos"],
            "sent_compound": s["compound"],
        })

    # Небольшая пауза, чтобы не спамить сайт
    time.sleep(random.uniform(1.0, 2.5))

# Превращаем все в DataFrame
df = pd.DataFrame(all_data)
print("\nПервые строки итогового DataFrame:")
print(df.head())

# Сохраним в CSV для отчета
df.to_csv("imdb_reviews_sentiment.csv", index=False, encoding="utf-8")
print("\nДанные сохранены в imdb_reviews_sentiment.csv")


# -----------------------------------------------------------------------------
# 4. Предварительная очистка / фильтрация
# -----------------------------------------------------------------------------

# Удаляем строки без рейтинга пользователя
df_with_rating = df.dropna(subset=["user_rating"]).copy()

print(f"\nВсего отзывов: {len(df)}, с указанным рейтингом: {len(df_with_rating)}")


# -----------------------------------------------------------------------------
# 5. Простейший анализ: корреляция рейтинг vs compound
# -----------------------------------------------------------------------------

corr = df_with_rating[["user_rating", "sent_compound"]].corr()
print("\nКорреляция между рейтингом пользователя и compound-тональностью:")
print(corr)

# -----------------------------------------------------------------------------
# 6. Средняя тональность для каждого значения рейтинга
# -----------------------------------------------------------------------------

mean_sent_by_rating = (
    df_with_rating.groupby("user_rating")["sent_compound"]
    .mean()
    .reset_index()
    .sort_values("user_rating")
)

print("\nСредний compound по каждому рейтингу пользователя:")
print(mean_sent_by_rating)

# -----------------------------------------------------------------------------
# 7. Средняя тональность и средний рейтинг по каждому фильму
# -----------------------------------------------------------------------------

movie_stats = (
    df_with_rating.groupby("movie")
    .agg(
        mean_user_rating=("user_rating", "mean"),
        mean_sentiment=("sent_compound", "mean"),
        count_reviews=("review_text", "count")
    )
    .reset_index()
)

print("\nСтатистика по фильмам:")
print(movie_stats)

movie_stats.to_csv("movie_stats.csv", index=False, encoding="utf-8")
print("\nСтатистика по фильмам сохранена в movie_stats.csv")


# -----------------------------------------------------------------------------
# 8. Визуализации
# -----------------------------------------------------------------------------

plt.figure(figsize=(8, 5))
plt.scatter(df_with_rating["user_rating"], df_with_rating["sent_compound"], alpha=0.6)
plt.xlabel("Рейтинг пользователя (1–10)")
plt.ylabel("Тональность (compound)")
plt.title("Связь между рейтингом пользователя и тональностью отзыва")
plt.grid(True)
plt.tight_layout()
plt.savefig("scatter_rating_vs_sentiment.png", dpi=200)
plt.show()

# Средний compound по рейтингу
plt.figure(figsize=(8, 5))
plt.plot(mean_sent_by_rating["user_rating"], mean_sent_by_rating["sent_compound"], marker="o")
plt.xlabel("Рейтинг пользователя")
plt.ylabel("Средний compound")
plt.title("Средняя тональность отзывов для каждого рейтинга")
plt.grid(True)
plt.tight_layout()
plt.savefig("mean_compound_by_rating.png", dpi=200)
plt.show()

# Для каждого фильма: средний рейтинг и средняя тональность
plt.figure(figsize=(10, 6))
plt.scatter(movie_stats["mean_user_rating"], movie_stats["mean_sentiment"])

for _, row in movie_stats.iterrows():
    plt.text(row["mean_user_rating"] + 0.02,
             row["mean_sentiment"] + 0.02,
             row["movie"],
             fontsize=8)

plt.xlabel("Средний рейтинг пользователей")
plt.ylabel("Средняя тональность (compound)")
plt.title("Сравнение средней тональности и рейтинга по фильмам")
plt.grid(True)
plt.tight_layout()
plt.savefig("movies_mean_rating_vs_sentiment.png", dpi=200)
plt.show()
