import requests
import json

# ==== ВСТАВЬ СВОИ ДАННЫЕ ====
CLIENT_ID          = "54375885"                     # твой ID приложения
REDIRECT_URI       = "https://oauth.vk.com/blank.html"
AUTHORIZATION_CODE = "vk2.a.Zc-QFWaZYP9OBIhS5wMZlNbyTEGBRNsQqLI0FDFWMEzluRFfModnuu8C8qRef16C4S_6vM9bKf-L7VZjD0pieX3nlay8zklR0dkLzWhmC3tSxWUoDpDXxqrDSlfwFhCnR8URBG8PXFmQ-XMvJ7D4XQ-mgyEKi4pMFy4BOoEBnjlxq3FkGwJb46tlWIwKKjW8dS8uYir9BzMCkF2qR3kYTQ"          # code из адресной строки
DEVICE_ID          = "3ONZzewDhxG7wQ8lOQgw1LPGUSH3Fwf6ssGVi15TaR8_W-xXsvQOrAuBWjevzMIGQvI-dZXRzNHFYvWpMbbEiw"              # device_id из адресной строки
CODE_VERIFIER      = "Ojzx_d4xKFEOoIzwXuEipXJC-3TG0YA_elXO97uC0xyWp7K3wHikW_5Kj6ga8rr0hKQuEBuSxEy9YV6Xjrw1lMTaCOtzNg_Fm4r8mrGswqQbjLP5bL_H8fTNWs9AkF31"   # тот самый, с шага 1
STATE              = "12345"                       # то же самое, что в ссылке

TOKEN_EXCHANGE_URL = "https://id.vk.com/oauth2/auth"

payload = {
    "grant_type": "authorization_code",
    "code": AUTHORIZATION_CODE,
    "redirect_uri": REDIRECT_URI,
    "client_id": CLIENT_ID,
    "device_id": DEVICE_ID,
    "code_verifier": CODE_VERIFIER,
    "state": STATE
}

headers = {
    "Content-Type": "application/x-www-form-urlencoded"
}

response = requests.post(TOKEN_EXCHANGE_URL, data=payload, headers=headers)

print("Статус:", response.status_code)
try:
    token_data = response.json()
    print(json.dumps(token_data, indent=2, ensure_ascii=False))
except Exception:
    print(response.text)

